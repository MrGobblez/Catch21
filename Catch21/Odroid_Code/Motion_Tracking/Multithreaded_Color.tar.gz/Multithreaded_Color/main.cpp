#include <QtCore>
#include <QCoreApplication>
#include "camerainput.h"
#include "controll.h"
#include "process.h"

int main()
{
    int c;

    // Objects
    cameraInput *camera = new cameraInput();
    controll *troller = new controll();
    process *processer = new process();

    // Threads
    QThread *t1 = new QThread;
    QThread *t2 = new QThread;
    camera->moveToThread(t1);
    processer->moveToThread(t2);

    // Connections
    QObject::connect(t1, SIGNAL(started()), camera, SLOT(captureImage()));
    QObject::connect(camera, SIGNAL(capturedImage(IplImage*)), troller, SLOT(inputImage(IplImage*)));
    QObject::connect(t2, SIGNAL(started()), troller, SLOT(processerReady()));
    QObject::connect(troller, SIGNAL(image(IplImage*)), processer, SLOT(processImage(IplImage*)));
    QObject::connect(troller, SIGNAL(requestImage()), camera, SLOT(captureImage()));
    //QObject::connect(processer, SIGNAL(posXposY(int,int)), troller, SLOT(//GAKK));
    QObject::connect(processer, SIGNAL(readyForWork()), troller, SLOT(processerReady()));
    QObject::connect(processer, SIGNAL(processedImage(IplImage*)), troller, SLOT(processedImage(IplImage*)));

    // Starting
    t2->start();
    t1->start();

    // wait for key to exit
    while (true) {

    // Wait for a keypress
         c = cvWaitKey(10);
        if(c!=-1)
        {
            // If pressed, break out of the loop
            break;
        }
    }
    return 0;
}
